ÉBÉNÉNEWS 72.8 — PACK MUSIQUE ORIGINAL

8 instrumentaux originaux générés spécialement pour le projet :
1. Intro
2. Direct
3. Morning
4. Night
5. Energy
6. Relax
7. Sport
8. Closing

Les MP3 sont originaux et peuvent servir de musique de fond à la radio.
Ils ne sont pas des reprises de chansons commerciales.

Installation :
- Copie le dossier music/ dans ton projet.
- Pour ton AutoDJ, utilise PLAYLIST.txt.
- Pour le site, les chemins sont music/NOM-DU-FICHIER.mp3.

Pour une vraie radio publique/commerciale, vérifie aussi les obligations de droits de diffusion applicables à ton activité.
